import setuptools

setuptools.setup(
    name="transaction",
    version="0.0.1",
    author="Hamza abughazaleh",
    author_email="hamzaabughazaleh23@gmail.com",
    description="A small example package",
    url="https://github.com/Hamza-abughazaleh/transaction",
    packages=setuptools.find_packages(),
)