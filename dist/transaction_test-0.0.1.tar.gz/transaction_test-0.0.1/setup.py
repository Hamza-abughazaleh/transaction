import setuptools

setuptools.setup(
   name="transaction_test",
   version="0.0.1",
   author="Hamza",
   author_email="hamzaabughazaleh23@gmail.com",
   description="A small example package",
   url="https://github.com/Hamza-abughazaleh/transaction",
   packages=setuptools.find_packages(),
   classifiers=[
       "Programming Language :: Python :: 3",
       "License :: OSI Approved :: MIT License",
       "Operating System :: OS Independent",
   ],
)